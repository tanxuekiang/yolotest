#ifndef MYCLASS_H
#define MYCLASS_H

#include <QObject>
#include <opencv2/opencv.hpp>
#include<QImage>
using namespace cv;
class Myclass : public QObject
{
    Q_OBJECT
public:
    explicit Myclass(QObject *parent = nullptr);
    Q_INVOKABLE void CopyAndgetRealPath(const QString &uriString);
    Q_INVOKABLE void requestOpencv(const QString &contentUri,int funtionNum);
     Q_INVOKABLE void getsliderturn(int funtionNum);
void geturltosave(QString geturl);
     QImage mattoqimage(Mat mat);
    Mat qimagetomat(QImage image);


public:
        int slidenum;
        int gaosizh1;
        int gaosizhi2;
        QString getuurl;

    signals:
        void dataReceived(QString lpathss);
};

#endif // MYCLASS_H
