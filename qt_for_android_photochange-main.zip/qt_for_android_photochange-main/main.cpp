#include <QGuiApplication>
#include <QQmlApplicationEngine>
 #include <QtCore/private/qandroidextras_p.h>
#include<QFileInfo>
#include<QFile>
#include <QQmlContext>
#include <QDebug>
#include"Myclass.h"


int main(int argc, char *argv[])
{


    QGuiApplication app(argc, argv);
    qmlRegisterType<Myclass>("waycpp", 1, 0, "Myclass");
    QQmlApplicationEngine engine;

    const QUrl url(QStringLiteral("qrc:/qmlimge/main.qml"));
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
                         if (!obj && url == objUrl)
                             QCoreApplication::exit(-1);
                     }, Qt::QueuedConnection);

    engine.load(url);



    return app.exec();
}
